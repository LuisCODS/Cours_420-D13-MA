package videoPlayer;

public class stateEnregistre extends State {

	/**
	 * 
	 */
	@Override
	public void PassToPlay(Video video) {
		// TODO Auto-generated method stub

	}
	/**
	 * 
	 */
	@Override
	public void PassToPause(Video video) {
		// TODO Auto-generated method stub

	}
	/**
	 * 
	 */
	@Override
	public void PassToStop(Video video) {
		// TODO Auto-generated method stub

	}
	/**
	 * 
	 */
	@Override
	public void PassToAvancer(Video video) {
		// TODO Auto-generated method stub

	}
	/**
	 * 
	 */
	@Override
	public void PassToReculer(Video video) {
		// TODO Auto-generated method stub

	}
	/**
	 * 
	 */
	@Override
	public void PassToAnnule(Video video) {
		// TODO Auto-generated method stub

	}
	/**
	 * 
	 */
	@Override
	public void PassToEnregistre(Video video) {
		// TODO Auto-generated method stub

	}
	/**
	 * 
	 */
	@Override
	public void PassToRecord(Video video) {

	}

}
